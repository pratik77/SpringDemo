package com.capgemini.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.capgemini.dto.AccountsDTO;
import com.capgemini.dto.TransactionDTO;

@Component("dao")
public class AccountsDAO {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public List<AccountsDTO>getAccountDetails(AccountsDTO accountsDTO)
	{
		String sql=new String("select * from account_details "
				+ "where customer_name = '"+accountsDTO.getCustName()+"'");
		 List<AccountsDTO>accountdetailsList=jdbcTemplate.query(sql,new RowMapper<AccountsDTO>() {
			 
	            public AccountsDTO mapRow(ResultSet result, int rowNum) throws SQLException {
	                AccountsDTO accountsDTO = new AccountsDTO();
	                accountsDTO.setAccountNum(result.getString(1));
	                accountsDTO.setCustName(result.getString(2));
	                accountsDTO.setAccountType(result.getString(3));
	                accountsDTO.setAccountLoc(result.getString(4));
	                accountsDTO.setBalance(result.getDouble(5));
	                 
	                return accountsDTO;
	            }
	             
	        });
		return accountdetailsList;
	}

	public int getTransactionId() {
		// TODO Auto-generated method stub
		String sql=new String("SELECT transaction_id_seq.NEXTVAL FROM Dual");
		 int transId=(int)jdbcTemplate.queryForInt(sql);
		
		return transId;
	}

	public void insertTransactionDetails(TransactionDTO transactionDTO) {
		// TODO Auto-generated method stub
		String sql=new String("INSERT INTO transaction_details "
				+ "VALUES("+transactionDTO.getTransId()+",'"+transactionDTO.getTransDesc()+
				"',"+transactionDTO.getTransAmount()+",sysdate,'"+transactionDTO.getAccountNum()+"')");
		jdbcTemplate.update(sql);
	}

}

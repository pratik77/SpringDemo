package com.capgemini.truckbooking.service;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.BookingException;

public class TruckService implements ITruckService {

	
	private ITruckDao truckDao;
	
	public TruckService()
	{
		this.truckDao= new TruckDao();
	}
	
	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {
		// TODO Auto-generated method stub
		List<TruckBean> truckList=truckDao.retrieveTruckDetails();
		return truckList;
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		
		int status=0;
		status=truckDao.bookTrucks(bookingBean);
		return status;
	}

	@Override
	public int updateTruck(int truckId, int noOfTruckToBook) throws BookingException {
		// TODO Auto-generated method stub
		int update=0;
		update=truckDao.updateTruck(truckId, noOfTruckToBook);
		return update;
	}
	public int getBookingId() throws BookingException
	{
		int bookingId=truckDao.getBookingId();
		return bookingId;
	}

}

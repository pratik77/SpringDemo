package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.utility.DBUtil;

public class TruckDao implements ITruckDao {
	private static Logger logger=Logger.getLogger(com.capgemini.truckbooking.dao.TruckDao.class);
	ITruckDao truckDaoTemp;
	@Override
	public int getBookingId() throws BookingException {
		
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		int bookingId;
		
		String sql=new String("SELECT booking_id_seq.nextval FROM Dual");
		try
		{
		connStudent=DBUtil.createConnection();
		
		Statement stmt = connStudent.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY);
		
		ResultSet rset = stmt.executeQuery (sql);
		
		rset.next();
		logger.info("Booking Id extracted successfully. "+rset.getInt(1));
		bookingId=rset.getInt(1);
		
		}catch(SQLException se)
		{
			throw new BookingException("Problem in generating.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new BookingException("Problems in closing connection.",se);
			}
		}
		
		
		return bookingId;
		
	}

	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {
		// TODO Auto-generated method stub
		List<TruckBean> truckList=new ArrayList<TruckBean>();
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		
		String sql=new String("SELECT * FROM TruckDetails");
		try
		{
		connStudent=DBUtil.createConnection();
		
		Statement stmt = connStudent.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY);
		
		ResultSet rset = stmt.executeQuery (sql);
		logger.info("Truckbean table generated successfully. ");
		while(rset.next())
		{
			TruckBean truckBean=new TruckBean();
			truckBean.setTruckID(rset.getInt(1));
			truckBean.setTruckType(rset.getString(2));
			truckBean.setOrigin(rset.getString(3));
			truckBean.setDestination(rset.getString(4));
			truckBean.setCharges(rset.getFloat(5));
			truckBean.setAvailableNos(rset.getInt(6));
			
			truckList.add(truckBean);
			
		}
		
		}catch(SQLException se)
		{
			throw new BookingException("Problem in generating truck details.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new BookingException("Problems in closing connection.",se);
			}
		}
		
		
		return truckList;
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		int status=0;
		Date newDate=Date.valueOf(bookingBean.getDateOfTransport());
		
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		
		String sql=new String("INSERT INTO BookingDetails VALUES(?,?,?,?,?,?)");
		try
		{
		connStudent=DBUtil.createConnection();
		
		pstStudent=connStudent.prepareStatement(sql);
		
		
		pstStudent.setInt(1,bookingBean.getBookingID());
		pstStudent.setString(2,bookingBean.getCustId());
		pstStudent.setLong(3,bookingBean.getCustMobile());
		pstStudent.setInt(4,bookingBean.getTruckId());
		pstStudent.setInt(5,bookingBean.getNoOfTrucks());
		pstStudent.setDate(6,newDate);
		
		status=pstStudent.executeUpdate();
		logger.info("Truck Booked successfully with booing id: "+bookingBean.getBookingID());
		
		
		
		}catch(SQLException se)
		{
			throw new BookingException("Problem in booking.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new BookingException("Problems in closing connection.",se);
			}
		}
		return status;
	}

	@Override
	public int updateTruck(int truckId, int noOfTruckToBook) throws BookingException {
		// TODO Auto-generated method stub
		int update=0;
		
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		
		String sqlDelete=new String("UPDATE truckdetails set availableNos = availableNos- ? where truckid=?");
		
		try
		{
			connStudent=DBUtil.createConnection();
			
			
		pstStudent=connStudent.prepareStatement(sqlDelete);
		pstStudent.setInt(1,noOfTruckToBook);
		pstStudent.setInt(2,truckId);
		update=pstStudent.executeUpdate();
		logger.info("Truck table updated successfully: ");
		}
		catch(SQLException se)
		{
			throw new BookingException("Problem in updation.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new BookingException("Problems in closing connection.",se);
			}
		}
		return update;
	}
	
	@Override
	public int checkTrucks(int truckId) throws BookingException
	{
		
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		int check;
		
		String sql=new String("SELECT availableNos FROM Truckdetails where truckId= "+truckId);
		try
		{
		connStudent=DBUtil.createConnection();
		
		Statement stmt = connStudent.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY);
		
		ResultSet rset = stmt.executeQuery (sql);
		
		rset.next();
		logger.info("Truck availability checked successfully: "+rset.getInt(1));
		
		check=rset.getInt(1);
		
		
		}catch(SQLException se)
		{
			throw new BookingException("Please enter correct credentials.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new BookingException("Problems in closing connection.",se);
			}
		}
		
		
		return check;
	}
	
	@Override
	public int checkTruckId(int truckId) throws BookingException
	{
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		int count=0;
		
		String sql=new String("SELECT truckid FROM Truckdetails");
		try
		{
		connStudent=DBUtil.createConnection();
		
		Statement stmt = connStudent.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY);
		
		ResultSet rset = stmt.executeQuery (sql);
		
		while(rset.next())
		{
			if(rset.getInt(1)!=truckId)
				continue;
			else
			{
				count=1;
				return count;	
			}
		}
		
		logger.info("TruckId checked successfully: ");
		
		
		
		}catch(SQLException se)
		{
			throw new BookingException("Please enter correct credentials.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new BookingException("Problems in closing connection.",se);
			}
		}
		
		
		return count;
	}

}

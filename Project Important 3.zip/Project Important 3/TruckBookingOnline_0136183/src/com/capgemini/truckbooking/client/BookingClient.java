package com.capgemini.truckbooking.client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;

public class BookingClient {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int status=0;
		int check=0;
		String custId;
		int truckId;
		int noOfTrucks;
		long custMobile;
		String dateOfBooking;
		ITruckService truckService;
		ITruckDao truckDao;
		ITruckDao truckDaoTemp;
		BookingBean bookingBean;
		int bookingId = 0;
		
		String patternCustId="[A-Z][0-9]{6}";
		
		int swtch;
		
		System.out.println("Enter choice 1 or 2.");
		System.out.println("---------------------");
		swtch=sc.nextInt();
		
		switch(swtch)
		{
			case 1:
				check=0;
				status=0;
				System.out.println("Enter the custId");
				custId=sc.next();
				
				if(Pattern.matches(patternCustId,custId)==false)
				{	
					System.out.println("Please enter a valid custId");
					break;
				}
				truckService=new TruckService();
				
			List<TruckBean> truckList=new ArrayList();
			try {
				truckList = truckService.retrieveTruckDetails();
			} catch (BookingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
				
				System.out.println("Please see the truck details below.");
				
				for(TruckBean ts : truckList)
				{
					System.out.println(ts.toString());
				}
				
				System.out.println("Please enter the truckId:");
				truckId=sc.nextInt();
				
				if(truckId==1000 || truckId==2000 || truckId==1001 || truckId==2001 || 
						truckId==1002 || truckId==1003 || truckId==1004 || truckId==3005  )
				{
					System.out.println("Enter number of trucks");
					noOfTrucks=sc.nextInt();
					
					truckDao=new TruckDao();
					try {
						check=truckDao.checkTrucks(truckId);
					} catch (BookingException e) {
						// TODO Auto-generated catch block
						System.out.println("Problem in checking no. of trucks");
					}
					
					if(check>=noOfTrucks && noOfTrucks>0)
					{
						System.out.println("Entered no. of trucks available");
					}
					else
						break;
					
					System.out.println("Enter your mobile number");
					custMobile=sc.nextLong();
					
					if(custMobile<1000000000L || custMobile >9999999999L)
					{
						System.out.println("Please enter a valid phone number");
						break;
					}
					System.out.println("Enter date of booking in yyyy-MM-dd format.");
					dateOfBooking=sc.next();
					
					DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
					LocalDate date=LocalDate.parse(dateOfBooking,formatter);
					
					if(date.isAfter(LocalDate.now())==false)
					{
						System.out.println("Please enter valid date.");
					}
				
					try {
						bookingId=truckDao.getBookingId();
					} catch (BookingException e) {
						// TODO Auto-generated catch block
						System.out.println("Problem in fetching booking Id");
					}
					bookingBean=new BookingBean(bookingId,custId, custMobile,
							truckId, noOfTrucks, date);
					
					status=0;
					try {
						status=truckService.bookTrucks(bookingBean);
					} catch (BookingException e) {
						// TODO Auto-generated catch block
						System.out.println("Problem in booking");
					}
					System.out.println("Thank you. Your booking id is "+bookingId);
					if(status==1)
					{
						int update=0;
						truckDaoTemp=new TruckDao();
						
						try {
							update=truckDaoTemp.updateTruck(bookingBean.getTruckId(),bookingBean.getNoOfTrucks());
						} catch (BookingException e) {
							// TODO Auto-generated catch block
							System.out.println("Problem in updating truck details");
						}
						
					}
				}
				else
				{
					System.out.println("Please select from available truckIds");
					break;
				}
				
				
				
				break;
			
			case 2: System.exit(0);
					break;
			default:System.out.println("Please enter valid choice");
					break;
				
				}
		
		
		

	}

}

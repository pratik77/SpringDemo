package com.cg.dto;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="BOOK_TABLE")
public class Book implements Serializable {
	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", title=" + title + ", price=" + price
				+ ", authorSet=" + authorSet + "]";
	}
	private static final long serialVersionUID = 1L;
	public Book() {
		// TODO Auto-generated constructor stub
		
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int ISBN;
	String title;
	double price;
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "author_books", joinColumns = { @JoinColumn(name = "ISBN") }, inverseJoinColumns = { @JoinColumn(name = "authorId") })
	private Set<Author> authorSet=new HashSet();
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Set<Author> getAuthorSet() {
		return authorSet;
	}
	public void setAuthorSet(Set<Author> authorSet) {
		this.authorSet = authorSet;
	}
	public Set<Author> addAuthor(Author author)
	{
		this.getAuthorSet().add(author);
		return this.authorSet;
	}

}

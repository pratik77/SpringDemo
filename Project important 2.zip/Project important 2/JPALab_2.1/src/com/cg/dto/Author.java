package com.cg.dto;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name="Author_TABLE")
public class Author implements Serializable {
	@Override
	public String toString() {
		return "Author [ID=" + ID + ", name=" + name + "]";
	}
	private static final long serialVersionUID = 1L;
	public Author() {
		// TODO Auto-generated constructor stub
	}
	@Id
	
	int ID;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Set<Book> getBooks() {
		return books;
	}
	public void setBooks(Set<Book> books) {
		this.books = books;
	}
	String name;
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="authorSet")
	private Set<Book> books = new HashSet<>();
	

}

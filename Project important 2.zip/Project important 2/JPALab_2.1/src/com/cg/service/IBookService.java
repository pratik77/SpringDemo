package com.cg.service;

import java.util.List;

import com.cg.dto.Author;
import com.cg.dto.Book;

public interface IBookService {
	public List<Book> getAllBooks();
	public Author getAllBooksByAuthorName(String authorName);
	public List<Book> getAllBooksByPriceRange(double low ,double high);
	public Book getAuthorNameByBookId(int bookId);
}

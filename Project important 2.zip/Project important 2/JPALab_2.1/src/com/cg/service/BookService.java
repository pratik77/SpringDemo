package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.dao.BookDAO;
import com.cg.dao.IBookDAO;
import com.cg.dto.Author;
import com.cg.dto.Book;

public class BookService implements IBookService {
	IBookDAO bookDAO;
	public BookService() {
		// TODO Auto-generated constructor stub
		bookDAO=new BookDAO();
		
	}

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		
		return bookDAO.getAllBooks();
		
	}

	@Override
	public Author getAllBooksByAuthorName(String authorName) {
		// TODO Auto-generated method stub
		return bookDAO.getAllBooksByAuthorName(authorName);
	}

	@Override
	public List<Book> getAllBooksByPriceRange(double low, double high) {
		// TODO Auto-generated method stub
		return bookDAO.getAllBooksByPriceRange(low,high);
	}

	@Override
	public Book getAuthorNameByBookId(int bookId) {
		// TODO Auto-generated method stub
		return bookDAO.getAuthorNameByBookId(22);
	}

}

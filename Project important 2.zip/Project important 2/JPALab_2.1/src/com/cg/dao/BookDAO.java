package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.dto.Author;
import com.cg.dto.Book;


public class BookDAO implements IBookDAO {

	private EntityManager entityManager;

	
	public BookDAO() {
		// TODO Auto-generated constructor stub
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		String qStr = "SELECT book FROM Book book";
		TypedQuery<Book> query = entityManager.createQuery(qStr, Book.class);
		
		return query.getResultList();
		
	}

	@Override
	public Author getAllBooksByAuthorName(String authorName) {
		// TODO Auto-generated method stub
		String qStr = "SELECT author FROM Author author"
				+ " Where author.name=:pAuthor";
		TypedQuery<Author> query = entityManager.createQuery(qStr, Author.class);
		query.setParameter("pAuthor", authorName);
		Author author = query.getSingleResult();
		return author;
		
	}

	@Override
	public List<Book> getAllBooksByPriceRange(double low, double high) {
		// TODO Auto-generated method stub
		String qStr = "SELECT book FROM Book book WHERE book.price between :low and :high";
		TypedQuery<Book> query = entityManager.createQuery(qStr, Book.class);
		query.setParameter("low", low);
		query.setParameter("high", high);
		List<Book> bookList = query.getResultList();
		return bookList;
	}

	@Override
	public Book getAuthorNameByBookId(int bookId) {
		// TODO Auto-generated method stub
		String qStr = "SELECT book FROM Book book WHERE book.ISBN=:pBookID";
		TypedQuery<Book> query = entityManager.createQuery(qStr, Book.class);
		query.setParameter("pBookID", bookId);
		Book book = query.getSingleResult();
		return book;
	}

}

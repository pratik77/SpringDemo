package com.cg.client;
import com.cg.dto.Author;
import com.cg.dto.Book;
import com.cg.service.BookService;
import com.cg.service.IBookService;


public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		IBookService bookService;
		bookService=new BookService();
		
		System.out.println();
		System.out.println("******All Books******");
		for(Book book:bookService.getAllBooks())
			System.out.println(book);
		
		System.out.println();
		System.out.println("*****All books by author name*****");
		
		
		for(Book book: bookService.getAllBooksByAuthorName("Pratik").getBooks())
			System.out.println(book);
		
		System.out.println();
		System.out.println("******All books by Price Range*****");
		for(Book book:bookService.getAllBooksByPriceRange(300,1000))
			System.out.println(book);
		
		System.out.println();
		System.out.println("******All authors by bookId*****");
		for(Author author:bookService.getAuthorNameByBookId(22).getAuthorSet())
			System.out.println(author);
		
		
		
	}

}

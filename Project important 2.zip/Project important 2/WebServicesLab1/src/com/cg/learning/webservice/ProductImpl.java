package com.cg.learning.webservice;

import java.util.HashMap;
import java.util.Map;

import javax.jws.WebService;
@WebService(endpointInterface = "com.cg.learning.webservice.ProductServer")
public class ProductImpl  {

	

	
	public double findProductPrice(String prodName) {
		// TODO Auto-generated method stub
		
		HashMap<String,Product> productMap=new HashMap<String,Product>();
		ProductDB productDB=new ProductDB();
		productMap=productDB.getProductMap();
		
		for(Map.Entry<String,Product> entry: productMap.entrySet())
		{
			
			String prodNameCheck=entry.getKey();
			if(prodNameCheck.equals(prodName))
				return entry.getValue().getPrice();
			
		}
		
		return 0D;
	}

}

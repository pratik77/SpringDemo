package com.cg.learning.webservice;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;



public class Client {

	public static void main(String[] args) throws MalformedURLException {
		// TODO Auto-generated method stub
		URL url = new URL("http://localhost:9876/cs?wsdl");
		QName qname = new QName("http://webservice.learning.cg.com/",
				"ProductImplService");

		// Create, in effect, a factory for the service.
		Service service = Service.create(url, qname);

		// Extract the endpoint interface, the service "port".
		ProductServer endPointIntf = service.getPort(ProductServer.class);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Product name:");
		String prodName=sc.next();
		double prodPrice=endPointIntf.findProductPrice(prodName);
		if(prodPrice!=0D)
			System.out.println("Price of the Product:"+prodPrice);
		else
			System.out.println("Product does not exist");

	}

}

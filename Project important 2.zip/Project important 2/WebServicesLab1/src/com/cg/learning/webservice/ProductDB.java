package com.cg.learning.webservice;


import java.util.HashMap;

/**
 * 
 * @author yvalecha
 * Static DB class, hosting country details in a HashMap
 */
public class ProductDB {
	static HashMap<String, Product> productMap = getProductMap();
	
	static {
		if (productMap == null) {
			productMap = new HashMap<String, Product>();
			Product fridge = new Product( "Fridge", 10000);
			Product iPad = new Product( "IPad", 35000);
			Product earphones = new Product( "Earphones", 8000);
			Product miPad = new Product( "MiPad", 7000);

			productMap.put("Fridge", fridge);
			productMap.put("IPad", iPad);
			productMap.put("Earphones",earphones );
			productMap.put("MiPad", miPad);
		}

	}
	/**
	 * This is a getter method of HashMap
	 * @return HashMap<Integer, Country>
	 */
	public static HashMap<String, Product> getProductMap() {
		return productMap;
	}

}

package com.bill.presentation;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bill.dao.EBillDAOImpl;
import com.bill.dao.IEBillDAO;
import com.bill.dto.BillDetailsDTO;
import com.bill.dto.ConsumerDTO;
import com.bill.exception.EBillException;
import com.bill.service.EBillServiceImpl;
import com.bill.service.IEBillService;

/**
 * Servlet implementation class BillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BillDetailsDTO billDetailsDTO;
	IEBillService eBillServiceImpl;
	IEBillDAO eBillDAOImpl;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        // TODO Auto-generated constructor stub
        billDetailsDTO=new BillDetailsDTO();
        eBillServiceImpl=new EBillServiceImpl();
        eBillDAOImpl=new EBillDAOImpl();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		String action=request.getParameter("action");
		RequestDispatcher rd=null;
		switch(action)
		{
			case "1":
				
					List<ConsumerDTO>consumerList=new ArrayList<ConsumerDTO>();
			try {
				consumerList=eBillServiceImpl.selectConsumerDetails();
			} catch (EBillException e) {
				// TODO Auto-generated catch block
				out.println(e.getMessage());
			}
			
        		
        			
        			request.setAttribute("consumerList",consumerList);
        			rd=request.getRequestDispatcher("PrintConsumerList2.jsp");
        			rd.forward(request, response); 
        			break;
			case "2":
			String consNumber=request.getParameter("consNumber");
			
			ConsumerDTO consumerDTO;
			consumerDTO=new ConsumerDTO();
			try {
				consumerDTO=eBillServiceImpl.selectConsumerDetails(consNumber);
			} catch (EBillException e) {
				// TODO Auto-generated catch block
				out.println(e.getMessage());
			}
			request.setAttribute("consumerDTO",consumerDTO);
			rd=request.getRequestDispatcher("PrintConsumerInfo.jsp");
			rd.forward(request, response);
			break;
			
			case "3":
				String consumerNo=request.getParameter("consumerNo");
				request.setAttribute("consumerNo",consumerNo);
				List<BillDetailsDTO>billDetailsList=new ArrayList<BillDetailsDTO>();
				
			try {
				billDetailsList=eBillServiceImpl.selectBillDetails(consumerNo);
			} catch (EBillException e) {
				// TODO Auto-generated catch block
				out.println(e.getMessage());
			}
			request.setAttribute("billDetailsList",billDetailsList);
			rd=request.getRequestDispatcher("PrintBillDetails.jsp");
			rd.forward(request, response); 
			break; 
			
			case "4":
				String conNumber=request.getParameter("consNumber");
				String lastReading=request.getParameter("lastReading");
				String currReading=request.getParameter("currReading");
				
				try
				{
				if(conNumber.matches("^[1-9][0-9]{5}$")==false&&(lastReading.matches("^[0-9]{1,3}$")==false||
						lastReading.matches("^[0-9]{1,3}[.][0-9]{1,2}$")==false)&&
						(currReading.matches("^[0-9]{1,3}$")==false||
								currReading.matches("^[0-9]{1,3}[.][0-9]{1,2}$")==false))
					throw new EBillException("Please enter credentials in specified format");
				
				
				
				else
				{
				int conNumberInt=Integer.parseInt(conNumber);
				float currReadingFloat=Float.parseFloat(currReading);
				float lastReadingFloat=Float.parseFloat(lastReading);
				int check=0;
				int status=0;
				
				
				try {
					check=eBillDAOImpl.checkConsNumber(conNumberInt);
					
				} catch (EBillException e) {
					// TODO Auto-generated catch block
					out.println(e.getMessage());
				}
					
				if(check==0)
					out.println("Please enter valid consumer number");
				else
				{
					if(currReadingFloat>lastReadingFloat && 
							lastReadingFloat>0)
					{
						float units=currReadingFloat-lastReadingFloat;
						float netAmount=(float) (units*1.15+100);
						int billId;
						try {
							billId = eBillServiceImpl.getBillId();
						 	
						
							billDetailsDTO=new BillDetailsDTO(billId,conNumberInt,currReadingFloat
									,lastReadingFloat,units,netAmount);
							status=eBillServiceImpl.insertBillDetails(billDetailsDTO);
							
							//if(status!=0)
							//{
							ConsumerDTO consumer=eBillServiceImpl.selectConsumerDetails(conNumber);
		        			//out.println("hello");
		        			request.setAttribute("Bill",billDetailsDTO);
		        			request.setAttribute("consumer",consumer);
		        			rd=request.getRequestDispatcher("PrintBill.jsp");
		        			rd.forward(request, response);
								
							//}
							
						} catch (EBillException e) {
							// TODO Auto-generated catch block
							out.println(e.getMessage());
						}
						
					}
					else
					out.println("Please enter valid current month and last month meter details.");
				}
					
					
			}
				
			}catch(EBillException e)
				{
				out.println(e.getMessage());
			}
				
			default:break;			
				
		}		
				
}
}

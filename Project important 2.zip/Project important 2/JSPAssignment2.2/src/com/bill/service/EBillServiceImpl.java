package com.bill.service;

import java.util.ArrayList;
import java.util.List;

import com.bill.dao.EBillDAOImpl;
import com.bill.dao.IEBillDAO;
import com.bill.dto.BillDetailsDTO;
import com.bill.dto.ConsumerDTO;
import com.bill.exception.EBillException;

public class EBillServiceImpl implements IEBillService {

	IEBillDAO eBillDAOImpl;
	public EBillServiceImpl() {
		// TODO Auto-generated constructor stub
		eBillDAOImpl=new EBillDAOImpl();
	}

	@Override
	public int insertBillDetails(BillDetailsDTO billDetailsDTO) throws EBillException {
		// TODO Auto-generated method stub
		int status=eBillDAOImpl.insertBillDetails(billDetailsDTO);
		return status;
		
	}
	@Override
	public int getBillId() throws EBillException
	{
		int billId=eBillDAOImpl.getBillId();
		return billId;
	}
	@Override
	public ConsumerDTO selectConsumerDetails(String conNo) throws EBillException{
		return eBillDAOImpl.selectConsumerDetails(conNo);
		
	}
	@Override
	public List<ConsumerDTO> selectConsumerDetails() throws EBillException{
		List <ConsumerDTO> consumerList=new ArrayList<ConsumerDTO>();
		consumerList=eBillDAOImpl.selectConsumerDetails();
		return consumerList;
	}

	@Override
	public List<BillDetailsDTO> selectBillDetails(String consumerNo)
			throws EBillException {
		// TODO Auto-generated method stub
		List <BillDetailsDTO> billDetailsList=new ArrayList<BillDetailsDTO>();
		billDetailsList=eBillDAOImpl.selectBillDetails(consumerNo);
		return billDetailsList;
		
	}

	

}

package com.bill.exception;

public class EBillException extends Exception {

	public EBillException() {
		// TODO Auto-generated constructor stub
	}

	public EBillException(String message) {
		super(message);
		System.out.println(message);
	}

	public EBillException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public EBillException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EBillException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}

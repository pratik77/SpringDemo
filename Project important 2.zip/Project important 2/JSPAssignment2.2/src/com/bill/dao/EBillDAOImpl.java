package com.bill.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bill.dto.BillDetailsDTO;
import com.bill.dto.ConsumerDTO;
import com.bill.exception.EBillException;
import com.bill.util.DBUtil;

public class EBillDAOImpl implements IEBillDAO {

	public EBillDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int insertBillDetails(BillDetailsDTO billDetailsDTO) throws EBillException {
		// TODO Auto-generated method stub
		int status=0;
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		
		String sql=new String("INSERT INTO billdetails(bill_num,consumer_num,cur_reading,"
				+ "unitConsumed,netAmount) "
				+ "VALUES(?,?,?,?,?)");
		try
		{
		connStudent=DBUtil.createConnection();
		
		pstStudent=connStudent.prepareStatement(sql);
		
		
		pstStudent.setInt(1,billDetailsDTO.getBillNo());
		pstStudent.setInt(2,billDetailsDTO.getConsumerNumber());
		pstStudent.setFloat(3,billDetailsDTO.getCurrReading());
		pstStudent.setFloat(4,billDetailsDTO.getUnits());
		pstStudent.setFloat(5,billDetailsDTO.getNetAmount());
		
		status=pstStudent.executeUpdate();
		
		
		
		}catch(SQLException se)
		{
			throw new EBillException("Record not inserted");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new EBillException("Problems in closing connection.",se);
			}
		}
		return status;
	}

	@Override
	public int getBillId() throws EBillException {
		// TODO Auto-generated method stub
		
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		int billId;
		
		String sql=new String("SELECT seq_bill_num.nextval FROM Dual");
		try
		{
		connStudent=DBUtil.createConnection();
		
		Statement stmt = connStudent.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY);
		
		ResultSet rset = stmt.executeQuery (sql);
		
		rset.next();
		billId=rset.getInt(1);
		
		}catch(SQLException se)
		{
			throw new EBillException("Problem in generating.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new EBillException("Problems in closing connection.",se);
			}
		}
		
		
		return billId;
	}
	public int checkConsNumber(int consNumberInt) throws EBillException
	{
		int count=0;
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		try
		{
		connStudent=DBUtil.createConnection();
		
		String sql=new String("SELECT consumer_num FROM Consumers");
		
		Statement stmt = connStudent.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY);
		
		ResultSet rset = stmt.executeQuery (sql);
		
		while(rset.next())
		{
			if(rset.getInt(1)==consNumberInt)
			{
				count=1;
				try
				{
					DBUtil.closeConnection();
				}catch(SQLException se)
				{
					throw new EBillException("Problems in closing connection.",se);
				}
				return count;
				
				
			}
			else continue;	
		}
		

		
		
		
		}
		catch(SQLException se)
		{
			throw new EBillException("No nobile with such mobile id is available.");
		}
		
		finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new EBillException("Problems in closing connection.",se);
			}
		}
		return count;
	}
	
	public ConsumerDTO selectConsumerDetails(String conNo)throws EBillException{
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		ConsumerDTO consumerDTO=new ConsumerDTO();
		try{
		Connection con=DBUtil.createConnection();
		String sql="select * from consumers where consumer_num=?";
		
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(conNo));
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				consumerDTO.setConsumerNo(rs.getString(1));
				consumerDTO.setConsumerName(rs.getString(2));
				consumerDTO.setAddress(rs.getString(3));
			}
		}catch(SQLException e){
			throw new EBillException(e.getMessage());
			
			}
			return consumerDTO;
		}
	public List<ConsumerDTO> selectConsumerDetails()throws EBillException{
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		
		List<ConsumerDTO> consumerList=new ArrayList<ConsumerDTO>();
		try{
		Connection con=DBUtil.createConnection();
		String sql="select * from consumers";
		
			PreparedStatement ps=con.prepareStatement(sql);
			
			ResultSet rset=ps.executeQuery();
			while(rset.next()){
				ConsumerDTO consumerDTO=new ConsumerDTO();
				consumerDTO.setConsumerNo(rset.getString(1));
				consumerDTO.setConsumerName(rset.getString(2));
				consumerDTO.setAddress(rset.getString(3));
				consumerList.add(consumerDTO);
				
				
			}
		}catch(SQLException e){
			throw new EBillException(e.getMessage());
			
			}
			return consumerList;
		}

	@Override
	public List<BillDetailsDTO> selectBillDetails(String consumerNo) throws EBillException {
		// TODO Auto-generated method stub
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		
		List <BillDetailsDTO> billDetailsList=new ArrayList<BillDetailsDTO>();
		try{
		Connection con=DBUtil.createConnection();
		String sql=new String("select * from billdetails where consumer_num = "+Integer.parseInt(consumerNo));
		
			PreparedStatement ps=con.prepareStatement(sql);
			
			ResultSet rset=ps.executeQuery();
			while(rset.next()){
				BillDetailsDTO billDetailsDTO=new BillDetailsDTO();
				billDetailsDTO.setBillNo(rset.getInt(1));
				billDetailsDTO.setConsumerNumber(rset.getInt(2));
				billDetailsDTO.setCurrReading(rset.getFloat(3));
				billDetailsDTO.setUnits(rset.getFloat(4));
				billDetailsDTO.setNetAmount(rset.getFloat(5));
				Date dt=rset.getDate(6);
				
				billDetailsDTO.setDate(dt.toLocalDate());
				billDetailsList.add(billDetailsDTO);
				
				
			}
		}catch(SQLException e){
			throw new EBillException(e.getMessage());
			
			}
			return billDetailsList;
	}
		
	}




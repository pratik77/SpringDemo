package com.cg.learning.service;

import java.util.List;

import com.cg.learning.beans.Product;
import com.cg.learning.dao.IProductDAO;
import com.cg.learning.dao.ProductDAO;

public class ProductService implements IProductService {

	IProductDAO productDAO=null;
	public ProductService() {
		// TODO Auto-generated constructor stub
		productDAO=new ProductDAO();
	}

	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		
		return productDAO.getAllProduct();
	}

	@Override
	public Product insertProduct(Product product) {
		// TODO Auto-generated method stub
		return productDAO.insertProduct(product);
	}

}

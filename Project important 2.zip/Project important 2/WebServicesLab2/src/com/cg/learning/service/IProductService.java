/**
 * 
 */
package com.cg.learning.service;

import java.util.List;

import com.cg.learning.beans.Product;

/**
 * @author pratiksa
 *
 */
public interface IProductService {
	
	public List<Product>getAllProduct();
	public Product insertProduct(Product product);

}

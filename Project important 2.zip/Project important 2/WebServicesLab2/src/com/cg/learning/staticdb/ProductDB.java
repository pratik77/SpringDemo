package com.cg.learning.staticdb;


import java.util.HashMap;

import com.cg.learning.beans.Product;

/**
 * 
 * @author yvalecha
 * Static DB class, hosting country details in a HashMap
 */
public class ProductDB {
	static HashMap<Integer, Product> productMap = getProductMap();
	
	static {
		if (productMap == null) {
			productMap = new HashMap<Integer, Product>();
			Product fridge = new Product( 101,"Fridge", 10000);
			Product iPad = new Product( 102,"IPad", 35000);
			Product earphones = new Product(103, "Earphones", 8000);
			Product miPad = new Product( 104,"MiPad", 7000);

			productMap.put(101, fridge);
			productMap.put(102, iPad);
			productMap.put(103,earphones );
			productMap.put(104, miPad);
		}

	}
	/**
	 * This is a getter method of HashMap
	 * @return HashMap<Integer, Country>
	 */
	public static HashMap<Integer, Product> getProductMap() {
		return productMap;
	}

}

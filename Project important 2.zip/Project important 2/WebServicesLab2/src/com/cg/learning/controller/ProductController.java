package com.cg.learning.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


import com.cg.learning.beans.Product;
import com.cg.learning.service.IProductService;
import com.cg.learning.service.ProductService;


@Path("/products")
public class ProductController {
	IProductService productService;

	public ProductController() {
		productService = new ProductService();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getAllProduct() {
		List<Product> productList = productService.getAllProduct();
		return productList;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Product insertProduct(@FormParam("txtId") int txtId,
			@FormParam("txtName") String txtName,
			@FormParam("txtPrice") double txtPrice) {
		Product product = new Product();
		product.setId(txtId);
		product.setProdName(txtName);
		product.setPrice(txtPrice);
		return productService.insertProduct(product);
	}

}

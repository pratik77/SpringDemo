package com.cg.learning.beans;

public class Product {
	int id;
	String prodName;
	double price;
	public Product(int id,String prodName, double price) {
		super();
		this.id=id;
		this.prodName = prodName;
		this.price = price;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	

}

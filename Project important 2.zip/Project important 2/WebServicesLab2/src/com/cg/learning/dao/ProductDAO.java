package com.cg.learning.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import com.cg.learning.beans.Product;
import com.cg.learning.staticdb.ProductDB;

public class ProductDAO implements IProductDAO {

	static HashMap<Integer, Product> productMap = ProductDB.getProductMap();
	public ProductDAO() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		List<Product> productList = new ArrayList<Product>(productMap.values());
		return productList;
	}

	@Override
	public Product insertProduct(Product product) {
		// TODO Auto-generated method stub
		productMap.put(product.getId(), product);
		return product;
	}

}

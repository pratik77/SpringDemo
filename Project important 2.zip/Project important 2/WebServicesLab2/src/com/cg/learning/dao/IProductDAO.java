/**
 * 
 */
package com.cg.learning.dao;

import java.util.List;

import com.cg.learning.beans.Product;

/**
 * @author pratiksa
 *
 */
public interface IProductDAO {
	public List<Product>getAllProduct();
	public Product insertProduct(Product product);

}

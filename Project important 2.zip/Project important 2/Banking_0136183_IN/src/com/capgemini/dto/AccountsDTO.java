package com.capgemini.dto;

public class AccountsDTO 
{
	private String accountNum;
	private String custName;
	private String accountType;
	private String accountLoc;
	private double balance;
	public String getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountLoc() {
		return accountLoc;
	}
	public void setAccountLoc(String accountLoc) {
		this.accountLoc = accountLoc;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public AccountsDTO() {
		super();
	}
	

}

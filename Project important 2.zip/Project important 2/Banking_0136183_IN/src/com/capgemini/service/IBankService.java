package com.capgemini.service;

import java.util.List;

import com.capgemini.dto.AccountsDTO;
import com.capgemini.dto.TransactionDTO;
import com.capgemini.exception.BankException;

public interface IBankService 
{
	public List<AccountsDTO> getAccountDetails(String custName) throws BankException;

	public int getTransactionId() throws BankException;

	public void insertTransactionDetails(TransactionDTO transactionDTO)throws BankException;
	
}

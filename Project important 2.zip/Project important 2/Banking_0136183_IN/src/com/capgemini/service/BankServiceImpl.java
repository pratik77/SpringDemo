package com.capgemini.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.dao.AccountsDAO;
import com.capgemini.dao.IAccountsDAO;
import com.capgemini.dao.ITransactionDAO;
import com.capgemini.dao.TransactionDAO;
import com.capgemini.dto.AccountsDTO;
import com.capgemini.dto.TransactionDTO;
import com.capgemini.exception.BankException;

public class BankServiceImpl implements IBankService {
	IAccountsDAO accountsDAO;
	ITransactionDAO transactionDAO;
	

	public BankServiceImpl() {
		super();
		accountsDAO=new AccountsDAO();
		transactionDAO=new TransactionDAO();
	}


	


	@Override
	public List<AccountsDTO> getAccountDetails(String custName) throws BankException{
		// TODO Auto-generated method stub
		List<AccountsDTO> accountDetailsList=new ArrayList<AccountsDTO>();
		accountDetailsList= accountsDAO.getAccountDetails(custName);
		return accountDetailsList;
	}





	@Override
	public int getTransactionId() throws BankException {
		// TODO Auto-generated method stub
		int transId;
		transId=transactionDAO.getTransactionId();
		return transId;
	}





	@Override
	public void insertTransactionDetails(TransactionDTO transactionDTO)
			throws BankException {
		// TODO Auto-generated method stub
		transactionDAO.insertTransactionDetails(transactionDTO);
	}

}

package com.capgemini.dao;

import java.util.List;

import com.capgemini.dto.AccountsDTO;
import com.capgemini.exception.BankException;

public interface IAccountsDAO
{
	public List<AccountsDTO> getAccountDetails(String custName) throws BankException;

	
	
}

package com.capgemini.dao;

import com.capgemini.dto.TransactionDTO;
import com.capgemini.exception.BankException;

public interface ITransactionDAO 
{
	public int getTransactionId() throws BankException;

	public void insertTransactionDetails(TransactionDTO transactionDTO) throws BankException;

}

package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.dto.AccountsDTO;
import com.capgemini.exception.BankException;
import com.capgemini.utility.DBUtil;

public class AccountsDAO implements IAccountsDAO {

	public AccountsDAO() {
		// TODO Auto-generated constructor stub
	}

	/*Retrieving accountdetails into a list*/
	@Override
	public List<AccountsDTO> getAccountDetails(String custName)
			throws BankException {
		// TODO Auto-generated method stub
		
		List<AccountsDTO> accountDetailsList=new ArrayList<AccountsDTO>();
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		
		
		try{
			
		//creating connection	
		Connection con=DBUtil.createConnection();
		//SQL query
		String sql=new String("select * from account_details "
				+ "where customer_name = ? ");
		
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,custName);
			
			//executing the sql command
			ResultSet rset=ps.executeQuery();
			while(rset.next()){
				AccountsDTO accountsDTO=new AccountsDTO();
				accountsDTO.setAccountNum(rset.getString(1));
				accountsDTO.setAccountType(rset.getString(3));
				accountsDTO.setAccountLoc(rset.getString(4));
				accountsDTO.setBalance(rset.getDouble(5));
				
				
				accountDetailsList.add(accountsDTO);
				
				
			}
			//handling the exception
		}catch(SQLException e){
			throw new BankException(e.getMessage()+" and problem in retrieving from account_details.");
			
			}
			return accountDetailsList;
		
	}

}

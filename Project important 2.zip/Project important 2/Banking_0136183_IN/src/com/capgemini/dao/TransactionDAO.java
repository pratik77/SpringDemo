package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.dto.TransactionDTO;
import com.capgemini.exception.BankException;

import com.capgemini.utility.DBUtil;

public class TransactionDAO implements ITransactionDAO {

	public TransactionDAO() {
		// TODO Auto-generated constructor stub
		
	}

	/*Generation of Transaction ID*/
	@Override
	public int getTransactionId() throws BankException {
		// TODO Auto-generated method stub
		Connection connStudent=null;
		PreparedStatement pstStudent=null;
		int transId;
		
		//SQL query
		String sql=new String("SELECT transaction_id_seq.NEXTVAL FROM Dual");
		try
		{
			
		//creating connection
		connStudent=DBUtil.createConnection();
		
		Statement stmt = connStudent.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY);
		
		//executing the sql command
		ResultSet rset = stmt.executeQuery (sql);
		
		rset.next();
		
		transId=rset.getInt(1);
		
		//handling the exception
		}catch(SQLException se)
		{
			throw new BankException("Problem in generating transaction ID.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new BankException("Problems in closing connection.",se);
			}
		}
		
		
		return transId;
	}

	/*Insertion of transaction details into transaction_details table*/
	@Override
	public void insertTransactionDetails(TransactionDTO transactionDTO)
			throws BankException {
		// TODO Auto-generated method stub
		int status=0;
		
		
		Connection conn=null;
		PreparedStatement pst=null;
		
		//SQL query
		String sql=new String("INSERT INTO transaction_details VALUES(?,?,?,sysdate,?)");
		try
		{
		//creating connection
		conn=DBUtil.createConnection();
		
		pst=conn.prepareStatement(sql);
		
		
		pst.setLong(1,transactionDTO.getTransId());
		pst.setString(2,transactionDTO.getTransDesc());
		pst.setDouble(3,transactionDTO.getTransAmount());
		pst.setString(4,transactionDTO.getAccountNum());
		
		//executing the sql command
		status=pst.executeUpdate();
		
		
		
		//handling the exception
		}catch(SQLException se)
		{
			throw new BankException("Problem in transaction detail insertion.");
		}finally
		{
			try
			{
				DBUtil.closeConnection();
			}catch(SQLException se)
			{
				throw new BankException("Problems in closing connection.",se);
			}
		}
		
		
	}

}

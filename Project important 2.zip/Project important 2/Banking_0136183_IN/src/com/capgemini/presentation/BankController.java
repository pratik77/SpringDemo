package com.capgemini.presentation;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.dao.AccountsDAO;
import com.capgemini.dao.IAccountsDAO;
import com.capgemini.dto.AccountsDTO;
import com.capgemini.dto.TransactionDTO;
import com.capgemini.exception.BankException;
import com.capgemini.service.BankServiceImpl;
import com.capgemini.service.IBankService;

/**
 * Servlet implementation class BankController
 */
@WebServlet("/BankController")
public class BankController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	IAccountsDAO accountDAO;
	IBankService bankService;
    public BankController() {
        super();
        // TODO Auto-generated constructor stub
        accountDAO=new AccountsDAO();
        bankService = new BankServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String action=request.getParameter("action");
		PrintWriter out=response.getWriter();
		RequestDispatcher rd=null;
		
		switch(action)
		{
		case "1":
			String custName=request.getParameter("custName");
			List<AccountsDTO> accountDetailsList=new ArrayList<AccountsDTO>();
			try {
				/* Fetching the account details from accounts_details table and loading them
				in array list accountDetailsList */
				accountDetailsList= bankService.getAccountDetails(custName);
			} catch (BankException e) {
				// TODO Auto-generated catch block
				/* If error in fetching details then show the error in customer.jsp file */
				request.setAttribute("error",e.getMessage());
				rd=request.getRequestDispatcher("CustomerError.jsp");
				rd.forward(request, response);
			}
			
			
			/*If the array list size is not zero then print the list in AccountInfo.jsp */
			if(accountDetailsList.size()!=0)
			{
				request.setAttribute("custName",custName);
				request.setAttribute("accountDetailsList",accountDetailsList);
				rd=request.getRequestDispatcher("AccountInfo.jsp");
				rd.forward(request, response);
			}
			
			/* If the array list list is empty show no details about the customer name in 
			CustomerError.jsp page*/
			else
				try {
					throw new BankException("No records with customer name: "+custName+" found");
				} catch (BankException e) {
					// TODO Auto-generated catch block
					request.setAttribute("error",e.getMessage());
					rd=request.getRequestDispatcher("CustomerError.jsp");
					rd.forward(request, response);
				}
			break;
		
		case "2":
			TransactionDTO transactionDTO=new TransactionDTO();
			String accountNum=request.getParameter("accountNum");
			String debitBalance=request.getParameter("debitBalance");
			int transId=0;
			
			/*The function to generate the transaction ID*/
			try {
				 transId=bankService.getTransactionId();
			} catch (BankException e) {
				// TODO Auto-generated catch block
				/* If error in fetching transaction ID then show the error in customer.jsp file */
				request.setAttribute("error",e.getMessage());
				rd=request.getRequestDispatcher("CustomerError.jsp");
				rd.forward(request, response);
			}
			
			
			/*Setting the attributes of TransactionDTO class into an object */
			transactionDTO.setTransId(transId);
			transactionDTO.setTransDesc("ATM Debit");
			transactionDTO.setTransAmount(Double.parseDouble(debitBalance));
			transactionDTO.setAccountNum(accountNum);
			
			
			/*Insertion of transaction details into the transaction_details table */
			try {
				bankService.insertTransactionDetails(transactionDTO);
			} catch (BankException e) {
				// TODO Auto-generated catch block
				/* If error in insertion of data in transaction_details table
				   then show the error in customer.jsp file */
				request.setAttribute("error",e.getMessage());
				rd=request.getRequestDispatcher("CustomerError.jsp");
				rd.forward(request, response);
			}
			request.setAttribute("debitBalance",debitBalance);
			request.setAttribute("accountNum",accountNum);
			rd=request.getRequestDispatcher("TransactionSuccess.jsp");
			rd.forward(request, response);
			break;
			
		
			
		default:break;
			
		}
		
	}

}

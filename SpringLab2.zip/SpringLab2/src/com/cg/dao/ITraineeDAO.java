package com.cg.dao;

import com.cg.dto.TraineeDTO;

public interface ITraineeDAO {

	void insertTraineeDetails(TraineeDTO traineeDTO);

}

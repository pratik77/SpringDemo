package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.stereotype.Component;

import com.cg.dto.TraineeDTO;

@Component("dao")
public class TraineeDAO implements ITraineeDAO {

	EntityManagerFactory factory = Persistence
			.createEntityManagerFactory("JPA-PU");
	EntityManager entityManager = factory.createEntityManager();
	
	@Override
	public void insertTraineeDetails(TraineeDTO traineeDTO) {
		// TODO Auto-generated method stub
		entityManager.getTransaction().begin();
		entityManager.persist(traineeDTO);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		factory.close();
		
	}

}

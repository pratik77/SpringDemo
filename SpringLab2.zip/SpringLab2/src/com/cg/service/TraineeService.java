package com.cg.service;

import com.cg.dto.AdminDTO;

public class TraineeService implements ITraineeService {

	@Override
	public boolean checkAdmin(AdminDTO adminDTO) {
		// TODO Auto-generated method stub
		return false;
	}

}

package com.cg.service;

import com.cg.dao.ITraineeDAO;
import com.cg.dao.TraineeDAO;
import com.cg.dto.AdminDTO;
import com.cg.dto.TraineeDTO;

public class TraineeService implements ITraineeService {

	ITraineeDAO traineeDAO=null;
	
	public TraineeService() {
		
		this.traineeDAO = new TraineeDAO();
	}

	

	@Override
	public void insertTraineeDetails(TraineeDTO traineeDTO) {
		// TODO Auto-generated method stub
		traineeDAO.insertTraineeDetails(traineeDTO);
	}

}

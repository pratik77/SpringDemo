/**
 * 
 */
package com.cg.service;

import com.cg.dto.AdminDTO;
import com.cg.dto.TraineeDTO;

/**
 * @author pratiksa
 *
 */
public interface ITraineeService {

	
	void insertTraineeDetails(TraineeDTO traineeDTO);

}

package com.capgemini.truckbooking.client;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;

/**
 * Servlet implementation class TruckBookingController
 */
@WebServlet("/TruckBookingController")
public class TruckBookingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ITruckService truckService;
	ITruckDao truckDao;
	ITruckDao truckDaoTemp;
	BookingBean bookingBean;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TruckBookingController() {
        super();
        // TODO Auto-generated constructor stub
        truckService=new TruckService();
        truckDao=new TruckDao();
        bookingBean=new BookingBean();	
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String customerId=request.getParameter("customerId");
		PrintWriter out=response.getWriter();
		String action=request.getParameter("action");
		RequestDispatcher rd=null;
		
		List<TruckBean> truckList;
		switch(action)
		{
		case "1":
			String custId=request.getParameter("customerId");
			BookingBean bookingBeanTemp=new BookingBean();
			bookingBeanTemp.setCustId(custId);
			request.setAttribute("bookingBeanTemp",bookingBeanTemp);
			truckList=new ArrayList();
			try {
				truckList = truckService.retrieveTruckDetails();
			} catch (BookingException e1) {
				request.setAttribute("error",e1.getMessage());
				rd=request.getRequestDispatcher("Error.jsp");
				rd.forward(request, response); 
				// TODO Auto-generated catch block
				
			}
			request.setAttribute("truckList",truckList);
			
		//	for(TruckBean truckBean: truckList)
		//	{
		//		out.println(truckBean.getTruckID());
		//	}
			rd=request.getRequestDispatcher("PrintTruckDetails.jsp");
			rd.forward(request, response); 
			break;
		case "2":
			String truckIdString=request.getParameter("truckId");
			String noOfTrucksString=request.getParameter("noOfTrucks");
			String custMobileString=request.getParameter("custMobile");
			String dateOfBookingString=request.getParameter("dateOfBooking");
			String custIdNew=request.getParameter("custId");
			int check=0;
			int bookingId;
			int status=0;
			
			int truckId=Integer.parseInt(truckIdString);
			int noOfTrucks=Integer.parseInt(noOfTrucksString);
			long custMobile=Long.parseLong(custMobileString);
			
			DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate date=LocalDate.parse(dateOfBookingString,formatter);
			
			//Validation Block
			
			try {
				if(truckDao.checkTruckId(truckId)==0)
				{
					try {
						throw new BookingException("Truck Id not available.");
					} catch (BookingException e) {
						// TODO Auto-generated catch block
						request.setAttribute("error",e.getMessage());
						rd=request.getRequestDispatcher("Error.jsp");
						rd.forward(request, response); 
					}
				}
				else
					bookingBean.setTruckId(truckId);
			} catch (BookingException e) {
				// TODO Auto-generated catch block
				out.println(e.getMessage());
			}
			
			bookingBean.setNoOfTrucks(noOfTrucks);
			bookingBean.setCustMobile(custMobile);
			bookingBean.setCustId(custIdNew);
			
			if(date.isAfter(LocalDate.now())==false)
			{
				try {
					throw new BookingException("Enter valid date.");
				} catch (BookingException e) {
					// TODO Auto-generated catch block
					out.println(e.getMessage());
				} 
			}
			else
				bookingBean.setDateOfTransport(date);
			
		
			try {
				bookingId=truckService.getBookingId();
				bookingBean.setBookingID(bookingId);
			} catch (BookingException e) {
				// TODO Auto-generated catch block
				System.out.println("Problem in fetching booking Id");
			}
			
			try {
				check=truckDao.checkTrucks(truckId);
			} catch (BookingException e) {
				// TODO Auto-generated catch block
				System.out.println("Problem in checking no. of trucks");
			}
			
			try
			{
			if(check<noOfTrucks || noOfTrucks<0)
			{
				throw new BookingException("Entered amount of trucks not available");
			}
			}
			catch(BookingException b)
			{
				response.sendRedirect("ErrorCheck.html");
				break;
			}
			
			try {
				status=truckService.bookTrucks(bookingBean);
				if(status==1)
				{
					int update=0;
					
					
					try {
						update=truckService.updateTrucks(bookingBean.getTruckId(),bookingBean.getNoOfTrucks());
					} catch (BookingException e) {
						// TODO Auto-generated catch block
						out.println(e.getMessage());
					}
					out.println("Thank You. Booking Id generated successfully"+bookingBean.getBookingID());
					
				}
				
				
			} catch (BookingException e) {
				// TODO Auto-generated catch block
				out.println(e.getMessage());
			}
			break;
		
			
			
				
			
			
		default:break;	
				
				
		}
		
		
	}

}

/**
 * 
 */
package com.capgemini.truckbooking.service;
import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;

/**
 * @author pratiksa
 *
 */
public interface ITruckService 
{
	List<TruckBean>retrieveTruckDetails() throws BookingException;
	int bookTrucks(BookingBean bookingBean) throws BookingException;
	
	int getBookingId()throws BookingException;
	int updateTrucks(int truckId, int noOfTruckToBook) throws BookingException;

}

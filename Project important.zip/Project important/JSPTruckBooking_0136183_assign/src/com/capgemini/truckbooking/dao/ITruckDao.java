package com.capgemini.truckbooking.dao;

import java.util.List;

import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;

public interface ITruckDao 
{
	int getBookingId() throws BookingException;
	List<TruckBean>retrieveTruckDetails() throws BookingException;
	int bookTrucks(BookingBean bookingBean) throws BookingException;
	int updateTruck(int truckId,int noOfTruckToBook) throws BookingException;
	public int checkTrucks(int truckId) throws BookingException;
	int checkTruckId(int truckId)throws BookingException;

}
